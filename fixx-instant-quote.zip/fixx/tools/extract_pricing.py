"""Rebuilds src/seed/pricing/catalog.json (and the test fixture) from FIXX_pricing_catalog.xlsx.
Run after each weekly price check:  python tools/extract_pricing.py path/to/FIXX_pricing_catalog.xlsx
Reads cached values, so open and save the workbook in Excel/LibreOffice first so formulas are recalculated."""
import hashlib, json, sys, datetime
import openpyxl

src = sys.argv[1] if len(sys.argv) > 1 else "FIXX_pricing_catalog.xlsx"
wv = openpyxl.load_workbook(src, data_only=True)

def rows(name, start=2, last_col=None):
    ws = wv[name]
    hdr = [c.value for c in ws[1]][: last_col or ws.max_column]
    for r in ws.iter_rows(min_row=start, max_col=len(hdr)):
        if r[0].value not in (None, ""):
            yield dict(zip(hdr, [c.value for c in r]))

def iso(d):
    return d.date().isoformat() if isinstance(d, (datetime.datetime, datetime.date)) else None

num = lambda v: v if isinstance(v, (int, float)) else None

# ---- items
items = {}
for r in rows("Prices", last_col=19):
    items[r["Item_ID"]] = dict(
        id=r["Item_ID"], category=r["Category"], name=r["Item (English)"], spanish=r["Spanish_Name"], spec=r["Spec"],
        unit=r["Unit / Pack"], store=r["Store"], price=num(r["Current_Price_MXN"]), iva=r["IVA_Status"],
        checkDate=iso(r["Check_Date"]), flag=r["Flag"] or "none")

# ---- task lines
tasks = {}
for r in rows("Tasks", last_col=14):
    t = tasks.setdefault(r["Task_ID"], dict(id=r["Task_ID"], category=r["Category"], job=r["Job"], lines=[]))
    t["lines"].append(dict(
        id=r["Line_ID"], tier=r["Tier"], itemId=r["Item_ID"], qty=r["Qty_Used"], basis=r["Qty_Basis"],
        unitPrice=num(r["Unit_Price_MXN"]), type=r["Line_Type"], flag=r["Flag (lookup)"] or "none"))
for t in tasks.values():
    t["tiers"] = sorted({l["tier"] for l in t["lines"]}, key=lambda x: ["Budget", "Standard", "Premium", "1 t", "1.5 t", "2 t", "3 t"].index(x))

# ---- labor + wage floor (floor table lives in Min_Wage_Floor rows 14-57)
mw = wv["Min_Wage_Floor"]
daily = {mw.cell(r, 1).value: mw.cell(r, 2).value for r in range(3, 11)}
floors = {}
for r in range(14, 58):
    key = mw.cell(r, 1).value
    if key:
        floors[key] = dict(trade=mw.cell(r, 5).value, dailyMin=mw.cell(r, 6).value, estJobDays=mw.cell(r, 7).value,
                           billableDays=mw.cell(r, 8).value, floor=mw.cell(r, 9).value)
labor = {}
for r in rows("Labor_Rates", last_col=25):
    f = floors.get(r["Labor_Key"], {})
    labor[r["Labor_Key"]] = dict(
        key=r["Labor_Key"], taskId=r["Task_ID"], tierScope=r["Tier_Scope"], trade=r["Trade"], basis=r["Labor_Basis"],
        rateLow=num(r["Rate_Low"]), rateTypical=num(r["Rate_Typical"]), rateHigh=num(r["Rate_High"]), refQty=num(r["Ref_Qty"]),
        typicalRef=num(r["Typical_Labor_Ref_Job"]), confidence=r["Confidence"], flag=r["Labor_Flag"] or "none",
        checkedDate=iso(r["Checked_Date"]), estJobDays=f.get("estJobDays"), dailyMin=f.get("dailyMin"), floor=f.get("floor"))

urgency = [dict(level=r["Urgency_Level"], multiplier=r["Multiplier (input)"], uiLevel=r["UI_Level"], uiOption=r["UI_Option"])
           for r in rows("Urgency", last_col=9) if r["Urgency_Level"] in ("STANDARD", "MEDIUM", "HIGH", "EMERGENCY")]
diagnosis = [dict(trade=r["Trade"], low=num(r["Fee_Low"]), typical=num(r["Fee_Typical"]), high=num(r["Fee_High"]), flag=r["Flag"])
             for r in rows("Diagnosis_Fees", last_col=13) if r["Trade"] and not str(r["Trade"]).startswith("FIXX POLICY")]
idmap = {r["Old_Task_ID"]: r["Final_Task_ID"] for r in rows("Task_ID_Map", last_col=5) if r.get("Old_Task_ID")}

dates = [i["checkDate"] for i in items.values() if i["checkDate"]] + [l["checkedDate"] for l in labor.values() if l["checkedDate"]]
body = dict(tasks=tasks, items=items, labor=labor, dailyMin=daily, urgency=urgency, diagnosis=diagnosis, taskIdMap=idmap)
digest = hashlib.sha1(json.dumps(body, sort_keys=True, default=str).encode()).hexdigest()[:8]
catalog = dict(version=f"{max(dates)}-{digest}", **body)
json.dump(catalog, open("src/seed/pricing/catalog.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---- reference results from the workbook's own Quote_Builder (used by the acceptance tests)
qb = [dict(taskId=r["Task_ID"], tier=r["Tier"], urgency=r["Urgency"], materials=r["Materials_MXN (Summary base)"], laborKey=r["Labor_Key"],
           typicalLabor=num(r["Typical_Labor_MXN"]), multiplier=r["Urgency_Multiplier"], labor=num(r["Labor_MXN (MAX(typical, wage floor) × multiplier)"]),
           total=num(r["Customer_Total_MXN"]), payout=num(r["Pro_Payout_MXN (MAX(typical, floor) × multiplier)"]), status=r["Status"])
      for r in rows("Quote_Builder", last_col=15)]
json.dump(qb, open("tests/fixtures/quote_builder.json", "w", encoding="utf-8"), ensure_ascii=False)
print(f"catalog {catalog['version']}: {len(tasks)} tasks, {len(items)} items, {len(labor)} labor keys; fixture rows: {len(qb)}")
